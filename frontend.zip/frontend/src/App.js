import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';  // Corrected the import path
import ComplaintPage from './pages/ComplaintPage'; // Corrected the import path
import AdminPage from './pages/AdminPage'; // Ensure you have this AdminPage for the admin route
import './styles/styles.css';

const App = () => {
  const [user, setUser] = useState(null);  // State to store user information

  const handleLogin = (userInfo) => {
    setUser(userInfo); // Update user state with user details after login
  };

  return (
    <Router>
      <Routes>
        {/* Login Page */}
        <Route path="/" element={<LoginPage onLogin={handleLogin} />} />

        {/* Complaint Page (Visible to Student) */}
        <Route
          path="/complaint"
          element={user && user.role === 'student' ? <ComplaintPage studentId={user.studentId} /> : <LoginPage onLogin={handleLogin} />}
        />

        {/* Admin Page (Visible to Admin) */}
        <Route
          path="/admin"
          element={user && user.role === 'admin' ? <AdminPage /> : <LoginPage onLogin={handleLogin} />}
        />
      </Routes>
    </Router>
  );
};

export default App;
