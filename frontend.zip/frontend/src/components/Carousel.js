import React from 'react';
import 'frontend/src/components/Carousel.js';

const Carousel = () => {
  return (
    <div className="carousel">
      <div className="carousel-slides">
        <img src="frontend/src/components/image1.jpg" alt="School Event 1" />
        <img src="frontend/src/components/image2.jpg" alt="School Event 2" />
        <img src="frontend/src/components/image3.jpg" alt="School Event 3" />
      </div>
    </div>
  );
};

export default Carousel;
