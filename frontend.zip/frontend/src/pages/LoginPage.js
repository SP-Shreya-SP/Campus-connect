import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const LoginPage = ({ onLogin }) => {  // Expecting onLogin prop to update the user info in the parent component
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('student');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/login', {
        username,
        password,
        role,
      });

      if (response.data.success) {
        const userInfo = {  // Update the user info after successful login
          studentId: response.data.studentId,  // Assuming studentId is sent back by the backend
          role: response.data.role,  // Role will be sent back from the backend as well
        };

        onLogin(userInfo);  // Pass userInfo to parent component (App.js)

        setMessage('Login successful!');

        // Redirect based on the role
        if (role === 'student') {
          navigate('/complaint');  // Ensure you have the route for student complaints
        } else if (role === 'admin') {
          navigate('/admin');  // Ensure you have the route for admin
        }
      } else {
        setMessage(response.data.message);  // Show the error message from backend
      }
    } catch (error) {
      console.error('Error during login:', error);
      setMessage('Login failed: Something went wrong');
    }
  };

  return (
    <div className="login-container">
      <header className="login-header">
        <h1>Government High School, Lambapur, Uttarkannada</h1>
      </header>
      
      <div className="login-box">
        <h2>Login</h2>
        {message && <p className={`message ${message.includes('successful') ? 'success' : 'error'}`}>{message}</p>}
        <form onSubmit={handleLogin}>
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />

          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <label>Role:</label>
          <select value={role} onChange={(e) => setRole(e.target.value)} required>
            <option value="student">Student</option>
            <option value="admin">Admin</option>
          </select>

          <button type="submit">Login</button>
        </form>
      </div>

      <div className="school-info">
        <p>
        GHS Lambapur , this school has been a beacon of excellence in education since 1994. Despite being located in a low-population region, the 
students have consistently demonstrated a thirst for knowledge and a drive to succeed because of the unwavering support and guidance of the talented, friendly, and kind teachers. 
Their alumni have gone on to achieve remarkable success in various fields such as doctors, engineers, government officials etc. They are setting their unremarkable contribution towards 
the betterment and progress of students.
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
