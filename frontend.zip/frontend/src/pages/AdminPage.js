import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Pie } from 'react-chartjs-2'; // Import Pie chart component

const AdminPage = () => {
  const [complaints, setComplaints] = useState([]);
  const [message, setMessage] = useState('');
  const [categoryStats, setCategoryStats] = useState([]);

  // Fetch all complaints and complaint stats (complaints grouped by category) when the admin page loads
  useEffect(() => {
    // Fetch complaints
    axios
      .get('http://localhost:5000/complaints')
      .then((response) => {
        console.log('Complaints API Response:', response.data); // Debugging log
        if (response.data.success) {
          setComplaints(response.data.complaints || []); // Ensure default to empty array
        } else {
          setMessage('Failed to fetch complaints');
        }
      })
      .catch((error) => {
        console.error('Error fetching complaints:', error);
        setMessage('Error fetching complaints');
      });

    // Fetch complaint category stats
    axios
      .get('http://localhost:5000/complaints/category-stats')
      .then((response) => {
        console.log('Category Stats Response:', response.data); // Debugging log
        if (response.data.success) {
          setCategoryStats(response.data.stats || []); // Ensure default to empty array
        } else {
          setMessage('Failed to fetch category stats');
        }
      })
      .catch((error) => {
        console.error('Error fetching category stats:', error);
        setMessage('Error fetching category stats');
      });
  }, []);

  // Handle status change for each complaint
  const handleStatusChange = (complaintId, newStatus) => {
    axios
      .put(`http://localhost:5000/complaints/${complaintId}/status`, {
        status: newStatus,
      })
      .then((response) => {
        if (response.data.success) {
          setMessage('Complaint status updated successfully');
          // Update the specific complaint's status in the state
          setComplaints((prevComplaints) =>
            prevComplaints.map((complaint) =>
              complaint.id === complaintId ? { ...complaint, status: newStatus } : complaint
            )
          );
        } else {
          setMessage('Failed to update status');
        }
      })
      .catch((error) => {
        console.error('Error updating status:', error);
        setMessage('Failed to update status');
      });
  };

  // Prepare data for the Pie Chart (based on categoryStats)
  const chartData = {
    labels: categoryStats.map((stat) => stat.category),
    datasets: [
      {
        label: 'Complaints by Category',
        data: categoryStats.map((stat) => stat.count),
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  return (
    <div>
      <h2>Admin Dashboard</h2>
      {message && <p style={{ color: 'red' }}>{message}</p>}

      <h3>Complaint Categories Breakdown</h3>
      {categoryStats.length > 0 ? (
        <Pie data={chartData} />
      ) : (
        <p>No data available for category breakdown.</p>
      )}

      <h3>All Complaints</h3>
      <table border="1" style={{ width: '100%', textAlign: 'left', marginTop: '20px' }}>
        <thead>
          <tr>
            <th>Complaint ID</th>
            <th>Student ID</th>
            <th>Title</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {complaints.length > 0 ? (
            complaints.map((complaint) => (
              <tr key={complaint.id}>
                <td>{complaint.id}</td>
                <td>{complaint.student_id}</td>
                <td>{complaint.title}</td>
                <td>{complaint.status}</td>
                <td>
  <select
    value={complaint.status}
    onChange={(e) => {
      handleStatusChange(complaint.id, e.target.value);

      // Dynamically set the color based on the selected value
      e.target.style.color = 
        e.target.value === "Pending" ? "orange" : 
        e.target.value === "Noted" ? "blue" : 
        "green";
    }}
    style={{
      color: complaint.status === "Pending" ? "orange" :
             complaint.status === "Noted" ? "blue" :
             "green"
    }}
  >
    <option value="Pending" style={{ color: "orange" }}>Pending</option>
    <option value="Noted" style={{ color: "blue" }}>Noted</option>
    <option value="Resolved" style={{ color: "green" }}>Resolved</option>
  </select>
</td>

              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" style={{ textAlign: 'center' }}>
                No complaints available.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default AdminPage;
